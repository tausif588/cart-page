import "bootstrap/dist/css/bootstrap.min.css"
import "bootstrap/dist/js/bootstrap.bundle"
import Navbar from "./Component/Navbar"
import Banner from "./Component/Banner"
import Category from "./Component/Category"
import JoinUs from "./Component/JoinUs"
import Footer from "./Component/Footer"
import Testmonial from "./Component/Testmonial"
import Payment from "./Component/Payment"
import Products from "./Component/Products"
function App() {
  return (
    <div>
   <Navbar />   
   <Banner />
   <Category />
   <Products />
   <Payment />
   <Testmonial />
   <JoinUs />
   <Footer />
    </div>
  )
}

export default App