import { Swiper, SwiperSlide } from "swiper/react";
import { useEffect, useState } from "react";
// Import Swiper styles
import "swiper/css";
import "swiper/css/navigation";
// import required modules
import { Navigation } from "swiper";


function Products() {
      const [carts, setCarts] = useState([]);

      useEffect(() => {
        fetch("https://dummyjson.com/carts")
          .then((response) => response.json())
          .then((data) => setCarts(data.carts))
          .catch((error) => console.log(error));
      }, []);
// console.log(carts[0].id)
  return (
    <>
      <div className="main-product-section">
        <div className="heading-section">
          <h2 className="text-center">Popular Products</h2>
        </div>
        <div class="chair-main mt-4">
          <div class="container">
            <div class="swiper-section row">
              <Swiper
                navigation={true}
                modules={[Navigation]}
                className="mySwiper"
                breakpoints={{
                  0: { slidesPerView: 1, spaceBetween: 10 },
                  480: {
                    slidesPerView: 2,
                    spaceBetween: 10,
                  },
                  762: {
                    slidesPerView: 3,
                    spaceBetween: 10,
                  },
                  992: {
                    slidesPerView: 4,
                    spaceBetween: 10,
                  },
                  1200: {
                    slidesPerView: 5,
                    spaceBetween: 10,
                  },
                }}
              >
                {carts.map((prod, id) => (
                  // console.log(prod.products[0].title)
                  <SwiperSlide>
                    <div class="col">
                      <div class="chair">
                        <div class="chair-image">
                          <img src="chair2.png" alt="" />
                        </div>
                        <div class="chair-footer">
                          <h6>{prod.products[0].title}</h6>
                          <p>Chair</p>
                          <div className="d-flex justify-content-between align-items-center">
                            <h6>${prod.products[0].price}</h6>
                            <button>Add Item</button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </SwiperSlide>
                ))}
                {/* <SwiperSlide>
                  <div class="col">
                    <div class="chair">
                      <div class="chair-image">
                        <img src="chair2.png" alt="" />
                      </div>
                      <div class="chair-footer">
                        <h6>Armchair</h6>
                        <p>Light single chair</p>
                        <div className="d-flex justify-content-between align-items-center">
                          <h6>$145</h6>
                          <button>Add Item</button>
                        </div>
                      </div>
                    </div>
                  </div>
                </SwiperSlide>
                <SwiperSlide>
                  <div class="col">
                    <div class="chair">
                      <div class="chair-image">
                        <img src="chair2.png" alt="" />
                      </div>
                      <div class="chair-footer">
                        <h6>Armchair</h6>
                        <p>Light single chair</p>
                        <h6> $145</h6>
                      </div>
                    </div>
                  </div>
                </SwiperSlide>
                <SwiperSlide>
                  <div class="col">
                    <div class="chair">
                      <div class="chair-image">
                        <img src="chair2.png" alt="" />
                      </div>
                      <div class="chair-footer">
                        <h6>Armchair</h6>
                        <p>Light single chair</p>
                        <h6> $145</h6>
                      </div>
                    </div>
                  </div>
                </SwiperSlide>
                <SwiperSlide>
                  <div class="col">
                    <div class="chair">
                      <div class="chair-image">
                        <img src="chair2.png" alt="" />
                      </div>
                      <div class="chair-footer">
                        <h6>Armchair</h6>
                        <p>Light single chair</p>
                        <h6> $145</h6>
                      </div>
                    </div>
                  </div>
                </SwiperSlide>
                <SwiperSlide>
                  <div class="col">
                    <div class="chair">
                      <div class="chair-image">
                        <img src="chair2.png" alt="" />
                      </div>
                      <div class="chair-footer">
                        <h6>Armchair</h6>
                        <p>Light single chair</p>
                        <h6> $145</h6>
                      </div>
                    </div>
                  </div>
                </SwiperSlide>
                <SwiperSlide>
                  <div class="col">
                    <div class="chair">
                      <div class="chair-image">
                        <img src="chair2.png" alt="" />
                      </div>
                      <div class="chair-footer">
                        <h6>Armchair</h6>
                        <p>Light single chair</p>
                        <h6> $145</h6>
                      </div>
                    </div>
                  </div>
                </SwiperSlide>
                <SwiperSlide>
                  <div class="col">
                    <div class="chair">
                      <div class="chair-image">
                        <img src="chair2.png" alt="" />
                      </div>
                      <div class="chair-footer">
                        <h6>Armchair</h6>
                        <p>Light single chair</p>
                        <h6> $145</h6>
                      </div>
                    </div>
                  </div>
                </SwiperSlide> */}
              </Swiper>
            </div>
            <div className="button-section">
              <div className="arrow-btn">
                <div className="left-btn">
                  <img src="right.png" alt="" />
                </div>
                <div className="right-btn">
                  <img src="left.png" alt="" />
                </div>
              </div>
              <div className="all-button">
                <button>
                  <span>All Categroies </span>
                  <img src="right-icon.png" alt="" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Products;
