import { useEffect, useState } from "react";


function Category() {
   const [data, setData] = useState([]);
    useEffect(() => {
      const fetchData = async () => {
        try {
          const response = await fetch(
            "https://dummyjson.com/products?limit=6"
          );
          const jsonData = await response.json();
          setData(jsonData.products);
        } catch (error) {
          console.error("Error fetching data:", error);
        }
      };

      fetchData();
    }, []);  
    return (
      <>
        <div className="category-section">
          <div className="container">
            <div className="row">
              <div className="col-md-12 text-center">
                <h2>Category Part</h2>
              </div>
            </div>
            <div className="row">
              <div className="col-md-3 category-left-desktop">
                <div className="input-type">
                  <input
                    type="search"
                    className="form-control"
                    placeholder="search here"
                  />
                  <img src="input-search.png" alt="" />
                </div>
                <div className="row">
                  <div className="col-md-12">
                    <div className="category-items" id="style3">
                      <span>Bedroom </span>
                      <span>Dinning Room</span>
                      <span>Meeting Room </span>
                      <span>Workspace</span>
                      <span>Living Room</span>
                      <span>Kitchen</span>
                      <span>Living Space</span>
                      <span>Bedroom </span>
                      <span>Dinning Room</span>
                      <span>Meeting Room </span>
                      <span>Workspace</span>
                      <span>Living Room</span>
                      <span>Kitchen</span>
                      <span>Living Space</span>
                      <span>Bedroom </span>
                      <span>Dinning Room</span>
                      <span>Meeting Room </span>
                      <span>Workspace</span>
                      <span>Living Room</span>
                      <span>Kitchen</span>
                      <span>Living Space</span>
                    </div>

                    <div className="category-btn">
                      <button>
                        <span>All Categroies </span>
                        <img src="right-icon.png" alt="" />
                      </button>
                      <div className="scroller-btn">
                        <div className="bottom">
                          <img src="up.png" alt="" />
                        </div>
                        <div className="up">
                          <img src="bottom.png" alt="" />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-3 category-left-mobile">
                <div className="row">
                  <div className="search-box">
                    <input
                      type="search"
                      className="form-control"
                      placeholder="search here"
                    />
                    <img src="input-search.png" alt="" />
                  </div>
                  <div className="tab-section">
                    <nav class="navbar navbar-expand-lg navbar-color for-mobile">
                      <div class="container-fluid">
                        <div className="navbar-brand input-type">
                          <input
                            type="search"
                            className="form-control"
                            placeholder="search here"
                          />
                          <img src="input-search.png" alt="" />
                        </div>

                        <button
                          class="navbar-toggler"
                          type="button"
                          data-bs-toggle="collapse"
                          data-bs-target="#navbarNav1"
                          aria-controls="navbarNav"
                          aria-expanded="false"
                          aria-label="Toggle navigation"
                        >
                          <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarNav1">
                          <ul class="navbar-nav">
                            <li class="nav-item">
                              <a
                                class="nav-link active"
                                aria-current="page"
                                href="#"
                              >
                                Home
                              </a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-link" href="#">
                                Features
                              </a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-link" href="#">
                                Pricing
                              </a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-link disabled">Disabled</a>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </nav>
                    <div className="for-tab">
                      <ul>
                        <li>Bedroom</li>
                        <li>Dinning Room</li>
                        <li>Meeting Room</li>
                        <li>Workspace</li>
                        <li>Living Room</li>
                        <li>Kitchen</li>
                        <li>Living Space</li>
                      </ul>
                      <div className="more-btn">
                        <button>
                          <span>All Categroies </span>
                          <img src="right-icon.png" alt="" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-9">
                <div className="row">
                  {data.map((ele, id) => (
                    <div className="col-12 col-sm-6 col-md-6 col-lg-6 mt-4">
                      <div className="box">
                        <div className="prodeuct-details">
                          <img src={ele.images[0]} alt="" />
                          <div className="title">
                            <p className="p-0 m-0 mt-2 text-center">{ele.title}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}

                  {/* <div className="col-12 col-sm-6 col-md-6 col-lg-6 mobile-mt">
                    <div className="box"></div>
                  </div> */}
                </div>
                {/* <div className="row mt-4">
                  <div className="col-12 col-sm-6 col-md-6 col-lg-6">
                    <div className="box"></div>
                  </div>
                  <div className="col-12 col-sm-6 col-md-6 col-lg-6 mobile-mt">
                    <div className="box"></div>
                  </div>
                </div>
                <div className="row mt-4">
                  <div className="col-12 col-sm-6 col-md-6 col-lg-6 ">
                    <div className="box"></div>
                  </div>
                  <div className="col-12 col-sm-6 col-md-6 col-lg-6 mobile-mt">
                    <div className="box"></div>
                  </div>
                </div> */}
              </div>
            </div>
          </div>
        </div>
      </>
    );
}

export default Category


