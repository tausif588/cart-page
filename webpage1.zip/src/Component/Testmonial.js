import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css/navigation";
import { Navigation } from "swiper";
// Import Swiper styles
import "swiper/css/navigation";
import "swiper/css";

function Testmonial() {
  return (
    <div className="testmonial-section">
      <div className="container">
        <div className="row">
          <div className="col-md-12">
            <div className="heading-section">
              <h2>Testimonials</h2>
              <p>Over 15,000 happy customers.</p>
            </div>
          </div>
        </div>
        <div className="swiper-slider-section">
          <p className="seeall">
            See all review
            <span>
              <img src="right.png" alt="" />
            </span>
          </p>
          <Swiper navigation={true} modules={[Navigation]} className="mySwiper">
            <SwiperSlide>
              <div className="row">
                <div className="col-12 col-md-4">
                  <div className="reviewer-img">
                    <img src="Image-container.png" alt="" />
                  </div>
                </div>
                <div className="col-12 col-md-7 d-flex justify-content-center align-items-center">
                  <div className="review">
                    <p className="review-title">
                      “My experience with Mark is a complete sucess, from
                      customer service, wide range of products, clean store,
                      purchasing experience, the newsletter.Thank you.”
                    </p>
                    <p className="reviewr-name">Leona Paul</p>
                    <p className="reviewer-post">CEO of Floatcom</p>
                  </div>
                </div>
                <div className="col-12 col-md-1 d-flex jusitfy-content-center align-items-center">
                  <div className="arrow-btn">
                    <div className="bottom">
                      <img src="left.png" alt="" />
                    </div>
                    <div className="up">
                      <img src="right.png" alt="" />
                    </div>
                  </div>
                </div>
              </div>
            </SwiperSlide>
            <SwiperSlide>
              <div className="row">
                <div className="col-12 col-md-4">
                  <div className="reviewer-img">
                    <img src="Image-container.png" alt="" />
                  </div>
                </div>
                <div className="col-12 col-md-7 d-flex justify-content-center align-items-center">
                  <div className="review">
                    <p className="review-title">
                      “My experience with Mark is a complete sucess, from
                      customer service, wide range of products, clean store,
                      purchasing experience, the newsletter.Thank you.”
                    </p>
                    <p className="reviewr-name">Leona Paul</p>
                    <p className="reviewer-post">CEO of Floatcom</p>
                  </div>
                </div>
                <div className="col-12 col-md-1 d-flex jusitfy-content-center align-items-center">
                  <div className="arrow-btn">
                    <div className="bottom">
                      <img src="left.png" alt="" />
                    </div>
                    <div className="up">
                      <img src="right.png" alt="" />
                    </div>
                  </div>
                </div>
              </div>
            </SwiperSlide>
            <SwiperSlide>
              <div className="row">
                <div className="col-12 col-md-4">
                  <div className="reviewer-img">
                    <img src="Image-container.png" alt="" />
                  </div>
                </div>
                <div className="col-12 col-md-7 d-flex justify-content-center align-items-center">
                  <div className="review">
                    <p className="review-title">
                      “My experience with Mark is a complete sucess, from
                      customer service, wide range of products, clean store,
                      purchasing experience, the newsletter.Thank you.”
                    </p>
                    <p className="reviewr-name">Leona Paul</p>
                    <p className="reviewer-post">CEO of Floatcom</p>
                  </div>
                </div>
                <div className="col-12 col-md-1 d-flex jusitfy-content-center align-items-center">
                  <div className="arrow-btn">
                    <div className="bottom">
                      <img src="left.png" alt="" />
                    </div>
                    <div className="up">
                      <img src="right.png" alt="" />
                    </div>
                  </div>
                </div>
              </div>
            </SwiperSlide>
          </Swiper>
        </div>
      </div>
    </div>
  );
}

export default Testmonial;
