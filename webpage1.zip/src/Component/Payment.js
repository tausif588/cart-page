function Payment() {
  return (
    <>
      <section class="payment-main py-5">
        <div class="container">
          <div class="row">
            <div class="col-sm-12">
              <div class="heading">
                <h1>Benefits for your expediency</h1>
              </div>
            </div>
            <div class="col-sm-12">
              <div class="row">
                <div class="col-12 col-sm-6 col-md-4 col-lg-4 col-xl-4">
                  <div class="payment">
                    <div class="payment-image py-4">
                      <img src="frame1.jpeg" alt="" />
                    </div>
                    <div class="pay-para">
                      <h6 class="pb-2">Payment Method</h6>
                      <p>We offer flexible payment options, to make easier.</p>
                    </div>
                  </div>
                </div>
                <div class="col-12 col-sm-6 col-md-4 col-lg-4 col-xl-4">
                  <div class="payment">
                    <div class="payment-image py-4">
                      <img src="frame2.jpeg" alt="" />
                    </div>
                    <div class="pay-para">
                      <h6 class="pb-2">Return policy</h6>
                      <p>You can return a product within 30 days.</p>
                    </div>
                  </div>
                </div>
                <div class="col-12 col-sm-6 col-md-4 col-lg-4 col-xl-4">
                  <div class="payment">
                    <div class="payment-image py-4">
                      <img src="frame3.jpeg" alt="" />
                    </div>
                    <div class="pay-para">
                      <h6 class="pb-2">Customer Support</h6>
                      <p>Our customer support is 24/7.</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

export default Payment