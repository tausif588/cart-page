export default function Navbar(){
    return (
      <nav class="navbar navbar-expand-lg  position-sticky">
        <div class="container">
          <div class="d-flex manage-order d-lg-none justify-content-between w-100">
            <div class="d-lg-none order-1">
              <a class="navbar-brand" href="#">
                <img src="logo.png" alt="" />
              </a>
            </div>
            <button
              class="navbar-toggler order-2 "
              type="button"
              data-bs-toggle="collapse"
              data-bs-target="#navbarNav"
              aria-controls="navbarNav"
              aria-expanded="false"
              aria-label="Toggle navigation"
            >
              <span class="navbar-toggler-icon"></span>
            </button>
            <div class="navbar-brand d-flex gap-4 d-lg-none order-3">
              <div className="search-i">
                <img src="search-icon.png" alt="" />
              </div>
              <div className="cart img">
                <img src="cart.png" alt="" />
              </div>
            </div>
          </div>
          <button
            class="navbar-toggler for-mobile"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarNav"
            aria-controls="navbarNav"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse " id="navbarNav">
            <div class="d-lg-flex for-mobile justify-content-between w-100">
              <div>
                <a class="navbar-brand" href="#">
                  <img src="logo.png" alt="" />
                </a>
              </div>
              <div>
                <ul class="navbar-nav">
                  <li class="nav-item">
                    <a class="nav-link dot-bottom" aria-current="page" href="#">
                      Home
                    </a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="#">
                      Products
                    </a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="#">
                      Categories
                    </a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link">About</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link">Contact</a>
                  </li>
                </ul>
              </div>
              <div className=" navbar-brand d-flex gap-4">
                <div className="search-i">
                  <img src="search-icon.png" alt="" />
                </div>
                <div className="cart img">
                  <img src="cart.png" alt="" />
                </div>
              </div>
            </div>
            <ul class="navbar-nav d-lg-none">
              <li class="nav-item">
                <a class="nav-link" aria-current="page" href="#">
                  Home
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">
                  Features
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">
                  Pricing
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link disabled">Disabled</a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    );
}