function JoinUs() {
  return (
    <div className="joinus-main-section container-fluid">
      <div className="row">
        <div className="col-md-6 p-0 pe-md-0">
          <div className="first-section"></div>
        </div>
        <div className="col-md-6 p-0 ps-md-0">
          <div className="joinus-section">
            <div className="heading-section">
              <h2>
                Join Our <br /> <span> Newsletter </span>{" "}
              </h2>
              <p>Receive exclusive deals, discounts and many offers.</p>
              <div className="input-box">
                <input
                  type="email"
                  className=""
                  placeholder="Enter your email"
                />
              </div>
              <div className="joinus-btn">
                <button>Subscribe</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default JoinUs