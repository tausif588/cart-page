import React, { useState } from 'react'
import { createContext } from 'vm'
export const dataTransfer=createContext();
function Context({children}) {
    const[newData,setNewData]=useState(0)
  return (
    <dataTransfer.Provder value={{ newData, setNewData }}>
      {children}
    </dataTransfer.Provder>
  );
}

export default Context