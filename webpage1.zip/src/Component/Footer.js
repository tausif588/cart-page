function Footer() {
  return (
    <div className="footer-section">
      <div className="container">
        <div className="row">
          <div className="col-md-4">
            <img src="logo.png" alt="" />
            <div className="social-media d-flex gap-3 mt-3 ">
              <img src="facebook.png" alt="" />
              <img src="instagram.png" alt="" />
              <img src="linkdin.png" alt="" />
              <img src="circle.png" alt="" />
              <img src="Twitter.png" alt="" />
            </div>
            <div className="address-details mt-4">
              <p className="address">Address</p>
              <p>+123 654 987</p>
              <p>877 The Bronx, NY</p>
              <p>14568, USA</p>
            </div>
          </div>
          <div className="col-md-8">
            <div className="row">
              <div className="col-md-4">
                <p className="address">My Account</p>
                <div>
                  <p>Sign In</p>
                  <p>Register</p>
                  <p>Order Status</p>
                </div>
              </div>
              <div className="col-md-4">
                <p className="address">Help</p>
                <div>
                  <p>Shipping</p>
                  <p>Returns</p>
                  <p>Sizing</p>
                </div>
              </div>
              <div className="col-md-4">
                <p className="address">Shop</p>
                <div>
                  <p>All Products</p>
                  <p>Bedroom</p>
                  <p>Dinning Room</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Footer