function Banner() {
  return (
    <div class="banner-section">
      <div class="container">
        <div class="title">
          <h2>
            Exclusive Deals of <br /> Furniture Collection{" "}
          </h2>
          <p>Explore different categories. Find the best deals.</p>
          <div class="title-btn">
            <button>Shop Now</button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Banner;
